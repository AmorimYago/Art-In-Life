package com.br.pi4.artinlife.model;

public enum Gender {
    MULHER_CIS,
    HOMEM_CIS,
    MULHER_TRANS,
    HOMEM_TRANS,
    NAO_BINARIO,
    OUTRO,
    NAO_INFORMADO
}
