package com.br.pi4.artinlife.model;

public enum UserType {
    ADMIN,
    STOCKER
}