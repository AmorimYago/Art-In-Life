package com.br.pi4.artinlife.repository;

import com.br.pi4.artinlife.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {}
