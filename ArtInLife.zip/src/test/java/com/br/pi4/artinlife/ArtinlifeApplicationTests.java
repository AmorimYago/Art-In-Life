package com.br.pi4.artinlife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtinlifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
